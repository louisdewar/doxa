print("Hello from python inside the VM")

x = input()
print("echo", x)
