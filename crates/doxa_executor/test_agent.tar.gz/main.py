x = input()
print("echo", x)
